package fracCalc;
import java.util.Scanner;
public class FracCalc {
	public static void main(String[] args){
		System.out.println("Welcome to FracCalc!\nType an equation to get started\nOr you can type \"quit\" to leave");
		Scanner scan = new Scanner(System.in);
		String x = scan.nextLine();
		while (!x.equals("quit")){
			String string1 = x.substring(0,x.indexOf(" "));
			String string2 = x.substring(x.lastIndexOf(" ") + 1);
			String operator = x.substring(x.indexOf(" ") + 1, x.lastIndexOf(" "));
			String simplified1 = simplify(string1);
			String simplified2 = simplify(string2);
			String num1 = simplified1.substring(0,simplified1.indexOf("/"));
			String num2 = simplified2.substring(0,simplified2.indexOf("/"));
			String den1 = simplified1.substring(simplified1.lastIndexOf("/")+1);
			String den2 = simplified2.substring(simplified2.lastIndexOf("/")+1);
			if (operator.equals("+")){
				int densum = Integer.parseInt(den1) * Integer.parseInt(den2);
				int numfix1 = Integer.parseInt(num1) * Integer.parseInt(den2);
				int numfix2 = Integer.parseInt(num2) * Integer.parseInt(den1);
				int numsum = numfix1 + numfix2;
				int gcd = gcd(numsum,densum);
				int numsum2 = numsum / gcd;
				int densim = densum / gcd;
				int numsim = numsum2 % densim;
				int whole = numsum / densum;
				if (densim == 1){
					System.out.println(whole);
				}
				else {
					System.out.println(whole + "_" + numsim + "/" + densim);
				}
			}
			if (operator.equals("-")){
				int densum = Integer.parseInt(den1) * Integer.parseInt(den2);
				int numfix1 = Integer.parseInt(num1) * Integer.parseInt(den2);
				int numfix2 = Integer.parseInt(num2) * Integer.parseInt(den1);
				int numsum = numfix1 - numfix2;
				int gcd = gcd(numsum,densum);
				int numsum2 = numsum / gcd;
				int densim = densum / gcd;
				int numsim = numsum2 % densim;
				int whole = numsum / densum;
				if (densim == 1){
					System.out.println(whole);
				}
				else {
					System.out.println(whole + "_" + numsim + "/" + densim);
				}
			}
			if (operator.equals("*")){
				int densum = Integer.parseInt(den1) * Integer.parseInt(den2);
				int numsum = Integer.parseInt(num1) * Integer.parseInt(num2);
				int gcd = gcd(numsum,densum);
				int numsum2 = numsum / gcd;
				int densim = densum / gcd;
				int numsim = numsum2 % densim;
				int whole = numsum / densum;
				if (densim == 1){
					System.out.println(whole);
				}
				else {
					System.out.println(whole + "_" + numsim + "/" + densim);
				}
			}
			if (operator.equals("/")){
				int numsum = Integer.parseInt(num1) * Integer.parseInt(den2);
				int densum = Integer.parseInt(den1) * Integer.parseInt(num2);
				int gcd = gcd(numsum,densum);
				int numsum2 = numsum / gcd;
				int densim = densum / gcd;
				int numsim = numsum2 % densim;
				int whole = numsum / densum;
				if (densim == 1){
					System.out.println(whole);
				}
				else {
					System.out.println(whole + "_" + numsim + "/" + densim);
				}
			}
			x = scan.nextLine();
		}
			System.out.println("Thanks for running FracCalc!");
	}

	public static int gcd(int a, int b) {
		while (b != 0){
		int t= b;
		b = a % b;
		a = t;
		}
		return a;
	}

	public static String simplify(String s) {
		if ( s.contains("_")){
			int underscorePos = s.indexOf("_");
			String wholePart = s.substring(0,underscorePos);
			String numeratorStr = s.substring(underscorePos +1 , s.indexOf("/"));
			String denominatorStr = s.substring(s.indexOf("/") +1);
			int numerator = Integer.valueOf(numeratorStr);
			int denominator = Integer.valueOf(denominatorStr);
			int whole = Integer.valueOf(wholePart);
			int newNumerator = whole * denominator + numerator;
			String newS = newNumerator + "/" + denominator;
			return newS;
		}
		else if (s.contains("/")){
			return s;
		}
		else {
			String newS2 = s + "/1";
			return newS2;
		}
	}
}
